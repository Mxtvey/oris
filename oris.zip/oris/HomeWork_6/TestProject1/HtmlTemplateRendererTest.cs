﻿namespace TestProject1;

[TestClass]
public sealed class HtmlTemplateRendererTest
{   
    
}